﻿using System.Windows;
using System.Windows.Controls;

namespace BookCollection
{
    public partial class BookDetailsControl : UserControl
    {
        public static readonly RoutedEvent BookDeleteEvent = EventManager.RegisterRoutedEvent(
            "BookDelete", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(BookDetailsControl));

        public event RoutedEventHandler BookDelete
        {
            add => AddHandler(BookDeleteEvent, value);
            remove => RemoveHandler(BookDeleteEvent, value);
        }

        // REJESTRACJA DEPENDENCY PROPERTY (Zadanie 6)
        public static readonly DependencyProperty IsBookReadProperty =
            DependencyProperty.Register("IsBookRead", typeof(bool), typeof(BookDetailsControl), new PropertyMetadata(false));

        public bool IsBookRead
        {
            get { return (bool)GetValue(IsBookReadProperty); }
            set { SetValue(IsBookReadProperty, value); }
        }

        public BookDetailsControl()
        {
            InitializeComponent();
            FormatComboBox.ItemsSource = Enum.GetValues(typeof(BookFormat));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Czy na pewno usunąć?", "Potwierdzenie", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                RaiseEvent(new RoutedEventArgs(BookDeleteEvent));
            }
        }

        private void Control_Changed(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.BooksListBox.Items.Refresh();
        }
    }
}