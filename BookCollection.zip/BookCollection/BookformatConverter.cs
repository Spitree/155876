﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace BookCollection
{
    public class BookFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is BookFormat format && format == BookFormat.PaperBack)
            {
                return new SolidColorBrush(Colors.LightGray);
            }
            return Brushes.Transparent; // Dla EBook tło pozostaje przezroczyste
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
