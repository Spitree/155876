﻿using System.Windows.Input;

namespace BookCollection
{
    public static class Commands
    {
        public static readonly RoutedUICommand DeleteBook = new RoutedUICommand(
            "Usuń wybraną książkę",
            "DeleteBook",
            typeof(Commands)
        );
    }
}