﻿using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace BookCollection
{
    public class GreenConverter : IValueConverter
    {
        // Ze Slidera (double) do Koloru tła (SolidColorBrush)
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double greenValue = value is double d ? d : 0;
            // Tworzymy kolor ARGB, gdzie składowa G (Green) jest sterowana wartością slidera
            return new SolidColorBrush(Color.FromRgb(100, (byte)greenValue, 100));
        }

        // Z TextBoxa/Tła z powrotem do Slidera
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string text && double.TryParse(text, out double result))
            {
                return result;
            }
            return 0.0;
        }
    }
}
