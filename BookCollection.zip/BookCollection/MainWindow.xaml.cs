﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace BookCollection
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Book> Books { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Books = new ObservableCollection<Book>(MyBookCollection.GetMyCollection());
            BooksListBox.ItemsSource = Books;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            int nextId = Books.Any() ? Books.Max(b => b.Id) + 1 : 1;
            Book newBook = new Book(nextId)
            {
                Title = "Nowa Pozycja",
                Author = "Nieznany",
                Year = 2026,
                Format = BookFormat.PaperBack,
                IsRead = false
            };
            Books.Add(newBook);
            BooksListBox.SelectedItem = newBook;
        }

        private void BookDetailsControl_BookDelete(object sender, RoutedEventArgs e)
        {
            ExecuteDeletion();
        }

        // IMPLEMENTACJA ROUTED COMMAND (Zadanie 7)
        private void DeleteBookCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            // Przycisk w Toolbarze jest aktywny tylko, gdy na liście zaznaczono książkę
            e.CanExecute = BooksListBox != null && BooksListBox.SelectedItem != null;
        }

        private void DeleteBookCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            // Usunięcie po kliknięciu przycisku na pasku zadań Toolbar
            ExecuteDeletion();
        }

        private void ExecuteDeletion()
        {
            if (BooksListBox.SelectedItem is Book selectedBook)
            {
                Books.Remove(selectedBook);
            }
        }
    }
}